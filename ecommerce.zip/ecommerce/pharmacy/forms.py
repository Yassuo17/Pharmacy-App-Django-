
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Product
from .models import Testimonial
from .models import InvoiceInfo
class SignUpForm(UserCreationForm):
    ROLE_CHOICES = (
        ('client', 'Client'),
        ('admin',  'Administrateur'),
        ('fournisseur', 'Fournisseur'),
    )
    email = forms.EmailField(required=True)
    role  = forms.ChoiceField(choices=ROLE_CHOICES, widget=forms.Select)

    class Meta:
        model  = User
        fields = ['username', 'email', 'password1', 'password2', 'role']
from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'price', 'description', 'image']

        

class TestimonialForm(forms.ModelForm):
    class Meta:
        model = Testimonial
        fields = ['message']
        widgets = {
            'message': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Racontez votre expérience...',
                'rows': 4,
            }),
        }


        

class InvoiceForm(forms.ModelForm):
    class Meta:
        model = InvoiceInfo
        fields = [
            'first_name', 'last_name', 'company_name', 'address', 'address_optional',
            'state_country', 'postal_zip', 'email', 'phone'
        ]

from django import forms
from .models import Product        
class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price', 'image']